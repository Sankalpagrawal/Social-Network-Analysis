# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import math
import random
import operator
import numpy as np
import node2vec

# Function to return the cosine-similarities between two vectors a and b
# cosine similarity = a.b / ||a|| * ||b||
def cosine_similarity(a,b):
	dot_product = 0
	magnitude_a = 0
	magnitude_b = 0
	for i in range(len(a)):
		x = a[i]
		y = b[i]
		magnitude_a += x**2
		magnitude_b += y**2
		dot_product += x*y
	return dot_product / math.sqrt(magnitude_a * magnitude_b)

# Function to find the L2_distance between two vectors a and b
# L2_distance = ||a-b||
def L2_distance(a,b):
	dist = 0
	for i in range(len(a)):
		x = a[i]
		y = b[i]
		dist += (x - y)**2
	return math.sqrt(dist)


# Function to find cosine similarities with source node embedding after obtaining vector representations from filename
# Returns the similarities sorted in decreasing order
def find_similarities(filename,source):
	n = 34  # Number of nodes
	embeddings = {}
	similarities = [(i,0) for i in range(n+1)]

	# the dictionary embeddings stores the vector embedding for each node
	with open(filename) as f:
		line = f.readline() # skip the first line, which has the number of nodes and embedding dimension
		line = f.readline()
		while line:
			l = list(map(float,line.strip().split(" ")))
			embeddings[l[0]] = l[1:]
			line = f.readline()

	# Store cosine similarity with source node embedding for every node
	for node in embeddings:
		cos = cosine_similarity(embeddings[source],embeddings[node])
		similarities[int(node)] = (int(node),cos)

	# Sort in reverse order
	similarities.remove((0,0))
	similarities.sort(key = operator.itemgetter(1),reverse=True)

	return similarities

# Function to find L2_distances with source node embedding after obtaining vector representations from filename
# Returns the distances in sorted order
def find_L2_distances(filename,source):
	n = 34	
	embeddings = {}
	L2_distances = [(i,0) for i in range(n+1)]

	# the dictionary embeddings stores the vector embedding for each node
	with open(filename) as f:
		line = f.readline() # skip the first line, which has the number of nodes and embedding dimension
		line = f.readline()
		while line:
			l = list(map(float,line.strip().split(" ")))
			embeddings[l[0]] = l[1:]
			line = f.readline()

	# Store L2_distance with source node embedding for every node
	for node in embeddings:
		dist = L2_distance(embeddings[source],embeddings[node])
		L2_distances[int(node)] = (int(node),dist)

	# Sort the list
	L2_distances.remove((0,0))
	L2_distances.sort(key=operator.itemgetter(1))

	return L2_distances




# ----------Problem_2a----------

# Loading the graph from "karate.edgelist" file to G
G = nx.Graph()
filename = "data\karate.edgelist.txt"
with open(filename) as f:
	line = f.readline()
	while line:
		a,b = list(map(str,line.strip().split(" ")))
		G.add_edge(int(a),int(b))
		line = f.readline()

# Draw the Karate Club graph in circular layout, with label names shown
nx.draw(G,pos=nx.circular_layout(G),with_labels=True)
plt.show()



# ----------Problem_2c----------

# Find the embeddings from in-built node2vec library functions
# Generate random walks first, with the following parameters
node2vec_2c = node2vec.Node2Vec(G, p=0.1, q=200, walk_length=100, num_walks=120)
# Embed the nodes
model_2c = node2vec_2c.fit()

# Save embeddings to a file
model_2c.wv.save_word2vec_format("EMBEDDING_FILENAME_2c")
filename = "EMBEDDING_FILENAME_2c"

# Find cosine similarities
similarities_2c = find_similarities(filename,33)

print()
print("Problem_2c")
print("Five nodes with the lowest shortest path distances to node 33: ")
print(str(similarities_2c[1][0]) + " " + str(similarities_2c[2][0]) + " " + str(similarities_2c[3][0]) + " " + str(similarities_2c[4][0]) + " " + str(similarities_2c[5][0]) )
print()



# ----------Problem_2d----------

# Find the embeddings from in-built node2vec library functions
# Generate random walks first, with the following parameters
node2vec_2d = node2vec.Node2Vec(G, p=200, q=0.1, walk_length=100, num_walks=120)
# Embed the nodes
model_2d = node2vec_2d.fit()

# Save embeddings to a file
model_2d.wv.save_word2vec_format("EMBEDDING_FILENAME_2d")
filename = "EMBEDDING_FILENAME_2d"

# Find cosine similarities
similarities_2d = find_similarities(filename,34)

print()
print("Problem_2d")
print("Five nodes that are also likely to have moderately high degrees: ")
print(str(similarities_2d[1][0]) + " " + str(similarities_2d[2][0]) + " " + str(similarities_2d[3][0]) + " " + str(similarities_2d[4][0]) + " " + str(similarities_2d[5][0]) )
print()



# ----------Problem_2e----------

# Find the embeddings from in-built node2vec library functions
# Generate random walks first, with the following parameters
node2vec_2e = node2vec.Node2Vec(G, p=100, q=0.01, walk_length=100, num_walks=120)
# Embed the nodes
model_2e = node2vec_2e.fit()

# Save embeddings to a file
model_2e.wv.save_word2vec_format("EMBEDDING_FILENAME_2e")
filename = "EMBEDDING_FILENAME_2e"

# Find L2 distances
L2_distances = find_L2_distances(filename,33)

print()
print("Problem_2e")
print("Node with closest distance to node 33: " + str(L2_distances[1][0]))
print("Degree of that node: " + str(G.degree(L2_distances[1][0])))
print("Degree of node 33: " + str(G.degree(33)))