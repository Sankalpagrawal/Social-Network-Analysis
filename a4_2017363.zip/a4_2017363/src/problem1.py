# Sankalp Agrawal, 2017363

# Import the libraries required
import networkx as nx
import matplotlib.pyplot as plt
import math
import random
from sklearn.metrics import roc_auc_score
import copy

# Loading the graph from "fb-pages-food.edges" file to G
G = nx.Graph()
filename = "data\\fb-pages-food\\fb-pages-food.edges"
with open(filename) as f:
	line = f.readline()
	while line:
		a,b = list(map(str,line.strip().split(",")))
		G.add_edge(int(a),int(b))
		line = f.readline()

# Function definitions for all Link Prediction Heuristics for graph G

# Returns Jaccard_index of edge (u,v) (intersection over union of N(u) and N(v))
def Jaccard_index(G,u,v):
	l1 = list(G[u])
	l2 = list(G[v])
	l1.extend(l2)
	union_size = len(set(l1))
	intersection_size = len(l1) - union_size
	if union_size==0:  # If union size==0 (to prevent ZeroDivisionError)
		return 0
	else:
		return intersection_size / union_size

# Returns Preferential Attachment index for edge (u,v) (product of number of neighbors for u and v)
def preferential_attachment(G,u,v):
	return len(G[u]) * len(G[v])

# Returns Adamic Adar index for edge (u,v) ( Sum of 1/log(|N(t)|), where t belongs to intersection of N(u),N(v) )
def Adamic_Adar_index(G,u,v):
	index = 0
	for neighbor in nx.common_neighbors(G,u,v):
		number_of_neighbors = len(G[neighbor])
		try:
			index += 1/math.log(number_of_neighbors)
		except ZeroDivisionError:  # if number of neighbors=0 or 1
			continue
	return index

# Returns number of Common neighbors of u and v in edge (u,v)
def common_neighbors(G,u,v):
	common_neighbors = 0
	for neighbor in nx.common_neighbors(G,u,v):
		common_neighbors+=1
	return common_neighbors


# Function to remove some percentage of edges from the graph, randomly chosen with replacement
# Returns the modified graph, along with the removed edges
def remove_edges(input_graph,percentage):
	G = copy.deepcopy(input_graph)
	edges_to_be_removed = int(G.number_of_edges() * percentage / 100) # number of edges to be removed
	edges_removed = []
	for num in range(edges_to_be_removed):
		# randomly choose an edge, if edge is already removed, continue, otherwise remove the edge
		edge = random.choice(list(G.edges()))  
		if G.has_edge(edge[0],edge[1]):
			edges_removed.append(edge)
			G.remove_edge(edge[0],edge[1])
		else:
			continue
	return G,edges_removed

# Function which performs max-normalization on the input array
def max_normalized(arr):
	maxim = max(arr)
	normalized_arr = []
	for i in arr:
		normalized_arr.append(i/maxim)
	return normalized_arr

# Function which runs the k-fold link prediction experiment for 10 folds (to find the average ROC-AUC score)
# Parameters: graph: the input graph; metric: the link prediction metric to be computed; percentage: % of edges to be removed  
# Returns the average ROC-AUC score across 10 folds for the given metric and percentage
def run_kfold_experiment(graph,metric,percentage):
	G = graph
	k=10
	roc_score = []

	for fold in range(k):
		# Number of edges which are not present initially would be the number of edges in the complement graph
		G_complement = nx.complement(G)
		initially_edges_not_present = list(G_complement.edges())

		# Remove the edges, and store new graph in G_new
		G_new,edges_removed = remove_edges(G,percentage)

		# Initialize array for true labels
		y_true = []
		# Initialize array for target scores(the probabilistic measure of being an actual edge)
		y_pred = []

		# The edges in the training set would be those which were not removed i.e the number of edges in G_new graph

		# The edges in the test set would be those, which were initially not present before removal + the edges which got removed
		# i.e initially_edges_not_present + edges_removed

		# The metric would be run on G_new graph, and the metric will be calculated for edges in test set
		# 0 would be appended to y_true for edges not present, 1 would be added to y_true for edges which were removed (as they were present earlier)
		
		for edge in initially_edges_not_present:
			y_true.append(0)
			if metric=="Jaccard_index":
				y_pred.append(Jaccard_index(G_new,edge[0],edge[1]))
			if metric=="common_neighbors":
				y_pred.append(common_neighbors(G_new,edge[0],edge[1]))
			if metric=="Adamic_Adar_index":
				y_pred.append(Adamic_Adar_index(G_new,edge[0],edge[1]))
			if metric=="preferential_attachment":
				y_pred.append(preferential_attachment(G_new,edge[0],edge[1]))

		for edge in edges_removed:
			y_true.append(1)
			if metric=="Jaccard_index":
				y_pred.append(Jaccard_index(G_new,edge[0],edge[1]))
			if metric=="common_neighbors":
				y_pred.append(common_neighbors(G_new,edge[0],edge[1]))
			if metric=="Adamic_Adar_index":
				y_pred.append(Adamic_Adar_index(G_new,edge[0],edge[1]))
			if metric=="preferential_attachment":
				y_pred.append(preferential_attachment(G_new,edge[0],edge[1]))

		# If metric is common_neighbors, preferential_attachment or adamic_adar, perform max-normalization to obtain the probabilistic score (a value between 0 and 1)
		# No need for max-normalization in Jaccard index (as it is already between 0 and 1)
		if metric=="common_neighbors" or metric=="preferential_attachment" or metric=="Adamic_Adar_index":
			y_pred = max_normalized(y_pred)

		# Append ROC-AUC for this fold to the array
		roc_score.append(roc_auc_score(y_true,y_pred))

	# Return average of the scores
	return sum(roc_score)/k


# Main Body
# Find values of average ROC-AUC for 25%,35%,45%,55% edges removed for all metrics
a1 = run_kfold_experiment(G,"common_neighbors",25)
a2 = run_kfold_experiment(G,"common_neighbors",35)
a3 = run_kfold_experiment(G,"common_neighbors",45)
a4 = run_kfold_experiment(G,"common_neighbors",55)

b1 = run_kfold_experiment(G,"Jaccard_index",25)
b2 = run_kfold_experiment(G,"Jaccard_index",35)
b3 = run_kfold_experiment(G,"Jaccard_index",45)
b4 = run_kfold_experiment(G,"Jaccard_index",55)

c1 = run_kfold_experiment(G,"Adamic_Adar_index",25)
c2 = run_kfold_experiment(G,"Adamic_Adar_index",35)
c3 = run_kfold_experiment(G,"Adamic_Adar_index",45)
c4 = run_kfold_experiment(G,"Adamic_Adar_index",55)

d1 = run_kfold_experiment(G,"preferential_attachment",25)
d2 = run_kfold_experiment(G,"preferential_attachment",35)
d3 = run_kfold_experiment(G,"preferential_attachment",45)
d4 = run_kfold_experiment(G,"preferential_attachment",55)

# Display the results
print("----------Common Neighbors----------")
print("Average ROC-AUC score across 10 folds")
print("When 25% edges are removed: " + str(a1))
print("When 35% edges are removed: " + str(a2))
print("When 45% edges are removed: " + str(a3))
print("When 55% edges are removed: " + str(a4))
print()
print("----------Jaccard_index----------")
print("Average ROC-AUC score across 10 folds")
print("When 25% edges are removed: " + str(b1))
print("When 35% edges are removed: " + str(b2))
print("When 45% edges are removed: " + str(b3))
print("When 55% edges are removed: " + str(b4))
print()
print("----------Adamic_Adar_index----------")
print("Average ROC-AUC score across 10 folds")
print("When 25% edges are removed: " + str(c1))
print("When 35% edges are removed: " + str(c2))
print("When 45% edges are removed: " + str(c3))
print("When 55% edges are removed: " + str(c4))
print()
print("----------preferential_attachment----------")
print("Average ROC-AUC score across 10 folds")
print("When 25% edges are removed: " + str(d1))
print("When 35% edges are removed: " + str(d2))
print("When 45% edges are removed: " + str(d3))
print("When 55% edges are removed: " + str(d4))

# Plot the graph b/w ROC-AUC score and percentage for all 4 metrics
x = [25,35,45,55]

plt.plot(x,[a1,a2,a3,a4], color='r', marker='o', label="common_neighbors")
plt.plot(x,[b1,b2,b3,b4], color='m', marker='o', label="Jaccard_index")
plt.plot(x,[c1,c2,c3,c4], color='g', marker='o', label="Adamic_Adar_index")
plt.plot(x,[d1,d2,d3,d4], color='y', marker='o', label="preferential_attachment")

plt.legend(loc='upper right')
plt.title("Average ROC-AUC score across 10 folds for Link Prediction metrics")
plt.ylabel("ROC-AUC score")
plt.xlabel("Percentage")
plt.show()