# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import operator
import random
import csv
import math

# Algorithm for computing exact betweenness centrality for all the edges in G
# Returns a dictionary of all edges with their betweenness values
def algorithm1(G):
	# initialize betweenness for all edges to 0
	betweenness = {}
	for e in G.edges():
		betweenness[e] = 0

	# Run loop for all nodes in G
	for s in list(G.nodes()):
		# Obtain Parent Set Ps(v), Count of Shortest Paths and levels obtained from the BFS tree
		parent_set, count_of_shortest_paths, levels = run_BFS(G,s)

		# Obtain dependencies of every edge on vertex s
		dependencies = get_dependencies(G,parent_set,count_of_shortest_paths,levels)

		# Add these to betweenness values
		for edge in dependencies:
			betweenness[edge] += dependencies[edge]

	return betweenness



# Algorithm for computing approximate betweenness centrality for all edges in G
# Returns a dictionary of all edges with their betweenness values
def algorithm2(G,c=5):

	# Maintain a dependency running sum for each edge
	n = G.number_of_nodes()
	dependency_running_sum = {}
	for e in G.edges():
		dependency_running_sum[e] = 0
	k = 0

	# Randomly sample n/10 nodes (with repitition) and run the algorithm for them only
	nodes = []
	for i in range(int(n/10)):
		node = random.choice(list(G.nodes()))
		nodes.append(node)

	for s in nodes:
		k += 1

		# Run BFS for vertex s and obtain dependencies (as in algo 1)
		parent_set, count_of_shortest_paths, levels = run_BFS(G,s)
		dependencies = get_dependencies(G,parent_set,count_of_shortest_paths,levels)
		for edge in dependencies:
			dependency_running_sum[edge] += dependencies[edge]

		# if ANY dependency running sum becomes greater than cn, break the loop and the value of k upto that point would be final number of samples considered
		if max(dependency_running_sum.values())>c*n:
			break

	# Finally, multiply each dependency running sum by n/k 
	for edge in dependency_running_sum:
		dependency_running_sum[edge] = n/k * dependency_running_sum[edge]

	return dependency_running_sum




############## Helper Functions ##############
##############################################


""" Function which modified BFS algorithm in such a way by also finding out the:
1) Parent set Ps(v): set of nodes which precede v on some shortest path from s to v
2) Counts of shortest paths: a 1-d array with count_of_shortest_path[i]=count of shortest paths from s to ith vertex
3) Levels obtained for each node as per the BFS tree: A 2d array with levels for each node
4) Distance of the node to s traversing the shortest path
Returns 1) , 2) and 3) as results (as arrays) 
"""
def run_BFS(G,s):
	# Initialize all the variables to consist 0
	count_of_shortest_paths = [0] * G.number_of_nodes()
	shortest_path_distance = [0] * G.number_of_nodes()
	parent_set_s = [[] for i in range(G.number_of_nodes())]
	levels = [[i,0] for i in range(G.number_of_nodes())]
	queue = []

	# Append source to queue and update count of shortest path values and shortest path distance
	queue.append(s)
	count_of_shortest_paths[s] = 1
	shortest_path_distance[s] = 1

	# start usual BFS:
	while queue!=[]:
		src_vertex = queue.pop(0)
		for neighbor in list(G.neighbors(src_vertex)):

			# if the neighbor is not visited i.e shortest path distance is 0,
			# count of shortest path would remain same
			# length of shortest path would increase by 1
			# Parent set of neighbor would include the src_vertex 
			# increment the level number
			if shortest_path_distance[neighbor]==0:
				count_of_shortest_paths[neighbor] = count_of_shortest_paths[src_vertex]
				shortest_path_distance[neighbor] = shortest_path_distance[src_vertex] + 1
				parent_set_s[neighbor].append(src_vertex)
				levels[neighbor][1] = levels[src_vertex][1] + 1
				queue.append(neighbor)

			# if the neighbor is already visited: ===> there is already a path reaching neighbor including few other vertices
			
			# Implying there are three cases:
			# 1. If distance of current path of reaching neighbor(including src_vertex) is smaller than previous path distance of reaching neighbor
			# 2. If distance of current path of reaching neighbor(including src_vertex) is equal to distance of previous path
			# 3. if distance of current path of reaching neighbor(including src_vertex) is larger than distance of previous path

			# Case 3 won't be considered as there the values of count of shortest paths, distance, parent set and levels would remain same

			else:
				# Case 1: if current path of reaching neighbor(including src_vertex) is smaller than previous path of reaching neighbor, then:
				# 1. count of shortest paths would be set to count for src_vertex
				# 2. distance of the path would be set to distance to src_vertex + 1 (as that path would become smaller)
				# 3. Parent set for neighbor would be reset to empty list (as new path would have to be considered)
				if shortest_path_distance[neighbor] > shortest_path_distance[src_vertex] + 1:
					parent_set_s[neighbor] = []
					shortest_path_distance[neighbor] = shortest_path_distance[src_vertex] + 1
					count_of_shortest_paths[neighbor] = count_of_shortest_paths[src_vertex]

				# Case 2: if distance of current path of reaching neighbor(including src_vertex) is equal to distance of previous path:
				# 1. then the shortest distance would remain same 
				# 2. number of paths would be increased by number of paths of reaching src_vertex 
				# 3. src_vertex is added to the parent set for neighbor 
				elif shortest_path_distance[neighbor] == shortest_path_distance[src_vertex]+1:
					parent_set_s[neighbor].append(src_vertex)
					count_of_shortest_paths[neighbor] += count_of_shortest_paths[src_vertex]

	return parent_set_s, count_of_shortest_paths, levels


# Function to find out the dependencies of every edge on source s (according to the recurrence given in question)
# returns a dictionary of dependencies for every edge
def get_dependencies(G,parent_set,count_of_shortest_paths,levels):
	# The nodes from the last level will be considered first, so sort the levels list 
	levels.sort(key = operator.itemgetter(1),reverse=True)
	dependencies = {}
	for e in G.edges():
		dependencies[e] = 0

	# delta_sum[i] will denote sum of dependencies of the nodes from parent set of node i 	
	delta_sum = dict.fromkeys(list(G.nodes()),0)

	# delta_sum[i] for nodes on last level would be 0
	for node,level in levels:
		for v in parent_set[node]:
			value = count_of_shortest_paths[v] * ((1 + delta_sum[node]) / count_of_shortest_paths[node])
			if (v, node) not in dependencies:
				dependencies[(node,v)] = value
			else:
				dependencies[(v,node)] = value
			delta_sum[v] += value

	return dependencies



############## Main Function #################
##############################################

if __name__=='__main__':

	# Generate the Barabasi Albert graph with m=4 and n=1000
	G = nx.barabasi_albert_graph(1000,4)

	# Obtain betweenness dictionaries from algo1 and algo2.. store the values to a csv file
	algo2_betweenness = algorithm2(G,5)
	algo1_betweenness = algorithm1(G)

	with open('algorithm2_values.csv', 'w+', newline='') as file:
		writer = csv.writer(file)
		writer.writerow(["Edge", "Betweenness value"])
		for edge in algo2_betweenness:
			writer.writerow([str(edge), str(algo2_betweenness[edge])])

	with open('algorithm1_values.csv', 'w+', newline='') as file:
		writer = csv.writer(file)
		writer.writerow(["Edge", "Betweenness value"])
		for edge in algo1_betweenness:
			writer.writerow([str(edge), str(algo1_betweenness[edge])])

	# Append betweeenness values to two lists for making the graph
	algo1_values = []
	algo2_values = []

	for edge in algo1_betweenness:
		algo1_values.append(algo1_betweenness[edge])

	for edge in algo2_betweenness:
		algo2_values.append(algo2_betweenness[edge])\

	# Obtain Mean absolute difference between values for algorithm 1 and algorithm 2
	difference=0
	for i in range(len(algo1_values)):
		difference += abs(algo1_values[i]-algo2_values[i])
	print("Mean absolute difference between values for algorithm 1 and algorithm 2: " + str(difference/len(algo2_values)))

	algo1_values.sort(reverse=True)
	algo2_values.sort(reverse=True)

	x = [i for i in range(1,G.number_of_edges()+1)]

	algo1_values = list(map(math.log10,algo1_values))
	algo2_values = list(map(math.log10,algo2_values))

	# Plot the graph for both algorithms 
	# Curve representing the ordering of edges based on betweenness centrality
	plt.plot(x,algo1_values,color='r',label="Algorithm 1")
	plt.plot(x,algo2_values,color='g',label="Algorithm 2")

	plt.legend(loc='upper right')
	plt.title("Curve representing the ordering of edges based on betweenness centrality")
	plt.ylabel("log(Betweenness)")
	plt.xlabel("Ordering of the edge")
	plt.show()