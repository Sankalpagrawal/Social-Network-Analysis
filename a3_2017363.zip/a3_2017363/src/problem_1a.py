# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt

# Loading the graph from "g1.edgelist.txt" and "g2.edgelist.txt" file to G1,G2
G1 = nx.Graph()
G2 = nx.Graph()
filename1 = "q1-data\g1.edgelist.txt"
filename2 = "q1-data\g2.edgelist.txt"
with open(filename1) as f:
	line = f.readline()
	while line:
		a,b,c = list(map(str,line.strip().split(" ")))
		G1.add_edge( int(a), int(b) )
		line = f.readline()

with open(filename2) as f:
	line = f.readline()
	while line:
		a,b,c = list(map(str,line.strip().split(" ")))
		G2.add_edge( int(a), int(b) )
		line = f.readline()

# The states array will represent the state of all the voters
# states[i] represents state of node i
# The undecided_nodes array will contain all the nodes who had initial state = "U" (undecided) 


# Function to initialize the votes A,B and U as per the conditions given in question.
# Returns: states of all voters(list), ids of undecided nodes(list)
def initialize_votes(G):
	states = []
	undecided_nodes = []
	for i in range(G.number_of_nodes()):
		last_digit = int(str(i)[-1]) # find the last digit of node id, and use it to assign votes
		if last_digit>=0 and last_digit<=3:
			states.append("B")
		elif last_digit>=4 and last_digit<=7:
			states.append("A")
		else:
			states.append("U")
			undecided_nodes.append(i)
	return states,undecided_nodes

# Function to simulate the decision process and final counting of votes i.e elections
# The winner is found out at the end by comparing votes gathered by A and B
def run_decision_process_and_elections(G):
	states, undecided_nodes = initialize_votes(G)  # assign initial states
	
	global_alternating_variable = "A"  # global alternating variable is set to "A" initially
	counts_dict = {}  # For storing counts of votes by neighbors of a particular undecided node

	for day in range(7):  # run a loop for a week i.e 7 times

		for node in undecided_nodes:
			counts_dict["A"] = 0
			counts_dict["B"] = 0
			counts_dict["U"] = 0
			for neighbor in G[node]:  # find counts of states for all neighbors of the node
				if states[neighbor]=="A":
					counts_dict["A"]+=1
				if states[neighbor]=="B":
					counts_dict["B"]+=1
				if states[neighbor]=="U":
					counts_dict["U"]+=1

			# assign votes 
			if counts_dict["A"]>counts_dict["B"]:
				states[node] = "A"
			if counts_dict["A"]<counts_dict["B"]:
				states[node] = "B"
			if counts_dict["A"]==counts_dict["B"]:  
				# resolve the tie by alternating variable, and alternate it's value after assigning vote
				states[node] = global_alternating_variable 
				if global_alternating_variable=="A":
					global_alternating_variable="B"
				else:
					global_alternating_variable="A"

	# elections time (counting of votes)
	votes_A = states.count("A")
	votes_B = states.count("B")

	print("Number of votes for candidate A: " + str(votes_A))
	print("Number of votes for candidate B: " + str(votes_B))
	if votes_A>votes_B:
		print("Candidate A wins by " + str(votes_A-votes_B) + " votes")
	if votes_B>votes_A:
		print("Candidate B wins by " + str(votes_B-votes_A) + " votes")


# Run the simulation function for both graphs, G1 and G2
print("For Graph G1: ")
run_decision_process_and_elections(G1)
print()
print("For Graph G2: ")
run_decision_process_and_elections(G2) 