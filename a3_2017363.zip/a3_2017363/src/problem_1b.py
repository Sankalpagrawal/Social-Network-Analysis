# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

# Loading the graph from "g1.edgelist.txt" and "g2.edgelist.txt" file to G1,G2
G1 = nx.Graph()
G2 = nx.Graph()
filename1 = "q1-data\g1.edgelist.txt"
filename2 = "q1-data\g2.edgelist.txt"
with open(filename1) as f:
	line = f.readline()
	while line:
		a,b,c = list(map(str,line.strip().split(" ")))
		G1.add_edge( int(a), int(b) )
		line = f.readline()

with open(filename2) as f:
	line = f.readline()
	while line:
		a,b,c = list(map(str,line.strip().split(" ")))
		G2.add_edge( int(a), int(b) )
		line = f.readline()

# The states array will represent the state of all the voters
# states[i] represents state of node i
# The undecided_nodes array will contain all the nodes who had initial state = "U" (undecided) 

# Function to initialize the votes as per the conditions given in question, and run advertisements when k Rupees are spent.
# Returns: states of all voters(list), ids of undecided nodes(list)
def initialize_votes_and_run_advertisements(G,k):
	states = []
	undecided_nodes = []
	for i in range(G.number_of_nodes()):
		last_digit = int(str(i)[-1])  # find the last digit of node id, and use it to assign votes
		if last_digit>=0 and last_digit<=3:
			states.append("B")
		elif last_digit>=4 and last_digit<=7:
			states.append("A")
		else:
			states.append("U")
			undecided_nodes.append(i)

	# Find number of people viewing, and assign their votes to A. Remove the swayed votes from undecided list.
	number_of_people_viewing = 10 * int(k/10000)
	for i in range(number_of_people_viewing):
		states[3000+i]="A"
		last_digit = int(str(i)[-1])
		if last_digit==8 or last_digit==9:
			undecided_nodes.remove(3000+i)

	return states,undecided_nodes	


# Function to simulate the decision process and final counting of votes i.e elections
# The winner is found out at the end by comparing votes gathered by A and B
# Returns final votes counted for A and B
def run_decision_process_and_elections(G,k):
	states, undecided_nodes = initialize_votes_and_run_advertisements(G,k) # assign initial states
	
	global_alternating_variable = "A"  # global alternating variable is set to "A" initially
	counts_dict = {}  # For storing counts of votes by neighbors of a particular undecided node

	for day in range(7):  # run a loop for a week i.e 7 times

		for node in undecided_nodes:
			counts_dict["A"] = 0
			counts_dict["B"] = 0
			counts_dict["U"] = 0
			for neighbor in G[node]:  # find counts of states for all neighbors of the node
				if states[neighbor]=="A":
					counts_dict["A"]+=1
				if states[neighbor]=="B":
					counts_dict["B"]+=1
				if states[neighbor]=="U":
					counts_dict["U"]+=1

			# assign votes
			if counts_dict["A"]>counts_dict["B"]:
				states[node] = "A"
			if counts_dict["A"]<counts_dict["B"]:
				states[node] = "B"
			if counts_dict["A"]==counts_dict["B"]:
				# resolve the tie by alternating variable, and alternate it's value after assigning vote
				states[node] = global_alternating_variable
				if global_alternating_variable=="A":
					global_alternating_variable="B"
				else:
					global_alternating_variable="A"

	# elections time (counting of votes)
	votes_A = states.count("A")
	votes_B = states.count("B")

	return votes_A,votes_B


# Run the simulation function for graph G1 for various valus of k (0, 10000, 20000, ... ,90000)
# Find votes won by for candidate A for each k
print("For Graph G1: ")
k = [0,10000,20000,30000,40000,50000,60000,70000,80000,90000]
votes_won_by = []
for i in range(len(k)):
	votes_A,votes_B = run_decision_process_and_elections(G1,k[i])
	votes_won_by.append(votes_A-votes_B)

# Find the minimum amount needed to win for A(-1 if A can't win)
minimum_amount_spent_to_win = -1
for i in range(len(votes_won_by)):
	if votes_won_by[i]>0:
		minimum_amount_spent_to_win = k[i] 
		break

# if A can't win, minimum amount spent = -1, else print the minimum amount
if minimum_amount_spent_to_win==-1:
	print("Candidate A can't win using 90,000 Rupees.")
else:
	print("Minimum amount spent to win: " + str(minimum_amount_spent_to_win))


# Plot the graph between number of votes won by v/s k for G1
plt.plot(k, votes_won_by, color='r', marker='o')
plt.title("Amount spend v/s Number of votes won by graph for G1")
plt.ylabel("Number of votes won by (for A)")
plt.xlabel("Amount spend(in Rupee)")
plt.xticks(np.arange(0, 90001, 10000)) 
plt.show()



# Repeat above process for G2
print("For Graph G2: ")
k = [0,10000,20000,30000,40000,50000,60000,70000,80000,90000]
votes_won_by = []
for i in range(len(k)):
	votes_A,votes_B = run_decision_process_and_elections(G2,k[i])
	votes_won_by.append(votes_A-votes_B)

# Find the minimum amount needed to win for A(-1 if A can't win)
minimum_amount_spent_to_win = -1
for i in range(len(votes_won_by)):
	if votes_won_by[i]>0:
		minimum_amount_spent_to_win = k[i] 
		break

# if A can't win, minimum amount spent = -1, else print the minimum amount
if minimum_amount_spent_to_win==-1:
	print("Candidate A can't win using 90,000 Rupees.")
else:
	print("Minimum amount spent to win: " + str(minimum_amount_spent_to_win))


# Plot the graph between number of votes won by v/s k for G2
plt.plot(k, votes_won_by, color='r', marker='o')
plt.title("Amount spend v/s Number of votes won by graph for G2")
plt.ylabel("Number of votes won by (for A)")
plt.xlabel("Amount spend(in Rupee)")
plt.xticks(np.arange(0, 90001, 10000))
plt.show()