# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import operator

# Loading the graph from "g1.edgelist.txt" and "g2.edgelist.txt" file to G1,G2
G1 = nx.Graph()
G2 = nx.Graph()
filename1 = "q1-data\g1.edgelist.txt"
filename2 = "q1-data\g2.edgelist.txt"
with open(filename1) as f:
	line = f.readline()
	while line:
		a,b,c = list(map(str,line.strip().split(" ")))
		G1.add_edge( int(a), int(b) )
		line = f.readline()

with open(filename2) as f:
	line = f.readline()
	while line:
		a,b,c = list(map(str,line.strip().split(" ")))
		G2.add_edge( int(a), int(b) )
		line = f.readline()

print("Average Clustering Coefficient for G1:")
print(nx.average_clustering(G1))
print("Average Clustering Coefficient for G2:")
print(nx.average_clustering(G2))