# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math
import operator

# Pagerank function, takes input graph G, parameter beta (teleport probability), maximum iterations
# Return an nx1 vector of PageRank Scores
def PageRank(G,beta,iters):
	n = G.number_of_nodes()
	M = np.zeros((n,n))
	one_vector = np.ones((n,1))
	r = 1/n * one_vector

	# Formulate Column Stochastic Matrix(M) 
	for i in range(n):
		for j in range(n):
			if G.has_edge(i+1,j+1):
				M[j,i]= G.number_of_edges(i+1,j+1) / G.out_degree(i+1) # Multiply with number of edges due to the possibility of multiedges
			else:
				M[j,i]=0

	# Run PageRank for 'iters' iterations
	for i in range(iters):
		r = (1-beta)/n * one_vector + beta*np.dot(M,r)

	return r

# First read G as a multidigraph(so that parallel edges could be included)
G = nx.MultiDiGraph()
filename = "graph.txt"
with open(filename) as f:
	line = f.readline()
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G.add_edge(a,b)
		line = f.readline()

n = G.number_of_nodes()
result = PageRank(G,0.8,40)
importance = []
# Store node ids along with PR score as a 2-tuple in importance list
for i in range(n):
	importance.append((i+1,float(result[i])) )

# Sort the PR scores and report results 
importance.sort(key = operator.itemgetter(1),reverse=True)
print("Top 5 node ids with the highest PageRank scores:")
print(str(importance[0][0]) + " " + str(importance[1][0]) + " " + str(importance[2][0]) + " " + str(importance[3][0]) + " " + str(importance[4][0]))
print("Bottom 5 node ids with the lowest PageRank scores:")
print(str(importance[99][0]) + " " + str(importance[98][0]) + " " + str(importance[97][0]) + " " + str(importance[96][0]) + " " + str(importance[95][0]))
