# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import collections
import math
import numpy as np
import random

# Function which returns the average clustering coefficient for graph G
# local clustering coefficient = 2/k(k-1) * (edges between the neighbors of v), where k is degree
# average clustering coefficient = average of local clustering coefficients for all the nodes
def find_average_clustering_coefficient(G):
	nodes = np.array(G.nodes())
	local_cc = []
	for i in range(n):
		nbr = list(G.neighbors(nodes[i]))
		Gsub = G.subgraph(nbr) # Obtain the subgraph spanned by neighbor of node i and count the edges in it
		degree = Gsub.number_of_nodes()
		if degree==0 or degree==1:
			local_cc.append(0) # local_cc = 0 if degree=0 or 1
		else:
			edges = Gsub.number_of_edges()
			cc = (2 *edges) / ((degree) * (degree-1))
			local_cc.append(cc)
	return sum(local_cc)/n

# making graph problem_3a

# Function which takes n(no. of nodes) and l(no. of edges) as parameters
# returns graph G which has randomly placed L links among n nodes
def make_erdos_renyi_graph(n,l):
	G = nx.Graph()
	for i in range(1,n+1):
		G.add_node(i)
	non_edges = list(nx.non_edges(G))
	random.shuffle(non_edges) # randomly arrange the ordering of non-edges
	random.shuffle(non_edges)
	for i in range(l):
		nonedge = non_edges[i] # add non-edge one by one to graph
		G.add_edge(nonedge[0],nonedge[1])
	return G

N=5242
L=14484
G1 = make_erdos_renyi_graph(N,L)


# making graph problem_3b

n=5242
G2 = nx.Graph()
for i in range(1,n+1):
	G2.add_node(i)

#part 1 (make a simple cycle from n nodes)
for i in range(1,n):
	if i==1:
		G2.add_edge(1,n)
	G2.add_edge(i,i+1)

#part 2 (make edges among two hop neighbors)
for i in range(1,n-1):
	if i==1:
		G2.add_edge(1,n-1)
	if i==2:
		G2.add_edge(2,n)
	G2.add_edge(i,i+2)

#part 3 (place 4000 edges randomly)
for _ in range(4000):
	u = random.randint(1,n)
	v = random.choice([j for j in range(1,n+1) if j not in [u-2,u-1,u,u+1,u+2]]) # exclude the case when the edge is already made
	G2.add_edge(u,v)


# making graph problem_3c
G3 = nx.Graph()
filename = "arxiv.txt"
# Load the graph from arxiv file
with open(filename) as f:
	for _ in range(5):
		line = f.readline()
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G3.add_edge(a,b)
		line = f.readline()
G3.remove_edges_from(nx.selfloop_edges(G3))


# Display the average clustering coefficient for all three graphs and the 
# graph with maximum average clustering coefficient
print("Average clustering coefficient for Erdos Renyi model (problem_3a):")
av1=find_average_clustering_coefficient(G1)
print(av1)
print("Average clustering coefficient for Watts Strogatz model (problem_3b):")
av2=find_average_clustering_coefficient(G2)
print(av2)
print("Average clustering coefficient for arxiv network (problem_3c):")
av3=find_average_clustering_coefficient(G3)
print(av3)
print()
print("Graph with highest average clustering coefficient: ")
if av1==max(av1,av2,av3):
	print("Graph 1 (problem_3a)")
if av2==max(av1,av2,av3):
	print("Graph 2 (problem_3b)")
if av3==max(av1,av2,av3):
	print("Graph 3 (problem_3c)")