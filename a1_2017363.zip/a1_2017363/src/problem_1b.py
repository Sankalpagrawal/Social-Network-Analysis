# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import collections
import math
from sklearn.linear_model import LinearRegression
import numpy as np

# Loading the graph from "Wiki-Vote.txt" file to G
G = nx.DiGraph()
filename = "wiki-Vote.txt"
with open(filename) as f:
	for _ in range(5):
		line = f.readline() # skip the written text part
	cnt = 1
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G.add_edge(a,b)
		line = f.readline()
		cnt += 1

# problem_1b part 1

# Obtain the degrees which appear in the graph and counts of nodes with those degrees
degree_sequence = sorted([d for n, d in G.out_degree()], reverse=True)
degrees = sorted(list(set(degree_sequence)))
counts = []
for i in degrees:
	counts.append(degree_sequence.count(i))

# Store log values of counts and degrees in degrees_log and counts_log 
degrees_log = []
counts_log = []
for i in degrees:
	if i==0:
		degrees_log.append(0)
	else:
		degrees_log.append(math.log10(i))
for i in counts:
	if i==0:
		counts_log.append(0)
	else:
		counts_log.append(math.log10(i))

# Plot the log(Nk) vs log(k) graph (bar chart)
fig, ax = plt.subplots()
plt.bar(degrees_log,counts_log, width=0.10, color='b', edgecolor='k')
plt.title("out-degree distribution of the wiki-Vote network")
plt.ylabel("log(Nk) where Nk=no.of nodes with degree k")
plt.xlabel("log(k) where k=degree")
plt.show()


# problem_1b part 2

# Y = mX + c is the regression equation, where Y is (n_samplesx1) vector and X is (n_samplesx2) vector 
# Get X in the form of 2d matrix. (Y is already in 1d form)
counts_reg = counts_log
degrees_reg = []
for i in degrees_log:
	l = [1,i]
	degrees_reg.append(l)

# perform the regression, obtain m and c as coefficients
reg = LinearRegression().fit(degrees_reg, counts_reg)
m=reg.coef_[1]
c=reg.intercept_

# draw the best fit line(red line), y=mx+c
x = np.linspace(0,2.5,50)
plt.bar(degrees_log,counts_log, width=0.10, color='b', edgecolor='k')
plt.title("out-degree distribution of the wiki-Vote network")
plt.ylabel("log(Nk) where Nk=no.of nodes with degree k")
plt.xlabel("log(k) where k=degree")
plt.plot(x, m*x+c, color='r', label='logy=m*logx+c')
plt.legend(loc='upper right')
plt.show()
