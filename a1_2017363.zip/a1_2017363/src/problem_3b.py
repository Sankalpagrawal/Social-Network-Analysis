# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import random

n=5242
G = nx.Graph()
for i in range(1,n+1):
	G.add_node(i)

#part 1 (make a simple cycle from n nodes)
for i in range(1,n):
	if i==1:
		G.add_edge(1,n)
	G.add_edge(i,i+1)
print("Number of edges after making cycle: "+ str(G.number_of_edges()))

#part 2 (make edges among two hop neighbors)
for i in range(1,n-1):
	if i==1:
		G.add_edge(1,n-1)
	if i==2:
		G.add_edge(2,n)
	G.add_edge(i,i+2)
print("Number of edges after making edges at two hop neighbours: "+str(G.number_of_edges()))

#part 3 (place 4000 edges randomly)
for _ in range(4000):
	u = random.randint(1,n)
	v = random.choice([j for j in range(1,n+1) if j not in [u-2,u-1,u,u+1,u+2]]) # exclude the case when the edge is already made
	G.add_edge(u,v)
print("Number of edges after adding 4000 random edges: "+str(G.number_of_edges()))