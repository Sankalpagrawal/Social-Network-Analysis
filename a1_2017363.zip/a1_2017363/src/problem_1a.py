# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt

# Loading the graph from "Wiki-Vote.txt" file to G
G = nx.DiGraph()
filename = "wiki-Vote.txt"
with open(filename) as f:
	for _ in range(5): # skip the written text part
		line = f.readline()
	cnt = 1
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G.add_edge(a,b)
		line = f.readline()
		cnt += 1

# problem_1a part 1
print("1. Number of nodes in graph: " + str(G.number_of_nodes()))

# problem_1a part 2
nodes_generator = nx.nodes_with_selfloops(G)
c = sum(1 for i in nodes_generator) # number of nodes obtained from the generator
print("2. Number of nodes having a self-loop: "+ str(c))

# problem_1a part 3
# Subtract number of selfloops from number of edges
print("3. Number of edges in the graph that are not self-loops: " + str(nx.number_of_edges(G) - nx.number_of_selfloops(G)))

# problem_1a part 4
# Subtract multiple edges from the total number of edges in the graph
G_undirected = G.to_undirected(reciprocal=True)
edges_counted_multipletimes = G_undirected.number_of_edges()
print("4. Number of unique pairs of vertices having an edge between them: " + str(G.number_of_edges()-edges_counted_multipletimes))

# problem_1a part 5
G_undirected = G.to_undirected(reciprocal=True)
print("5. Number of edges in G, such that (a,b) in E iff (b,a) in E: " + str(G_undirected.number_of_edges()))


# Store in-degree sequence in a list and out-degree sequence in lists
lin = list(G.in_degree())
lout = list(G.out_degree())

# problem_1a part 6
count6=0
for i in lin:
	if i[1]==0:
		count6+=1
print("6. Number of nodes with zero in-degree: " + str(count6))

# problem_1a part 7
count7=0
for i in lout:
	if i[1]==0:
		count7+=1
print("7. Number of nodes with zero out-degree: " + str(count7))

# problem_1a part 8
# Number of connected components reported are when G is considered as an undirected graph
G_undirected = nx.to_undirected(G)
print("8. Number of connected components in the network: " + str(nx.number_connected_components(G_undirected)))

# problem_1a part 9
count9=0
for i in lin:
	if i[1]>10:
		count9+=1
print("9. Number of nodes with in-degree>10: " + str(count9))

# problem_1a part 10
count10=0
for i in lout:
	if i[1]>10:
		count10+=1
print("10. Number of nodes with out-degree>10: " + str(count10))