# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math

# HITS function(self-made) which returns two dictionaries: h and a(hub scores and authority scores)
# Input parameters: G(directed graph), max_iters(maximum number of iterations). toI(error tolerance) 
def HITS(G,max_iters,toI):
	# Take all the nodes in nodes list
	nodes = np.array(G.nodes())
	n = len(nodes)

	# Make h,a dictionaries and initialize h and a values to 1/n
	h = {}
	a = {}
	for i in range(n):
		h[nodes[i]] = 1/n
		a[nodes[i]] = 1/n

	for itr in range(max_iters):
		prev_h = h # Store previous iteration values to prev_h
		h = {}
		a = {}
		for i in range(n): # Initialize all values to 0(for calculating hub and authority score)
			h[nodes[i]] = 0
			a[nodes[i]] = 0

		for node in h: # Calculate authority score for each node
			for neighbor in list(G.successors(node)): # Find neighbors of node
				a[neighbor]+=prev_h[node] # authority score = sum of all hub scores of pages which point to it

		# normalize auth scores by dividing by max value
		maxa = max(a.values())
		for i in nodes:
			a[i] = a[i] / maxa

		for node in h: # Calculate hub score for each node
			for neighbor in list(G.successors(node)):
				h[node]+=a[neighbor] # hub score = sum of all authority scores of pages which it points to

		# normalize hub scores by dividing by max value
		maxh = max(h.values())
		for i in nodes:
			h[i] = h[i] / maxh

		l1_norm=0  #Find l1_norm
		for i in nodes:
			l1_norm+=abs(prev_h[i]-h[i])

		# If l1_norm<toI, algorithm converges
		if l1_norm<toI:
			break

	# Normalize all h and a values at the end by dividing by the sum of all a and h values
	suma = sum(a.values())
	for i in nodes:
		a[i] = a[i] / suma
	sumh = sum(h.values())
	for i in nodes:
		h[i] = h[i] / sumh

	return h,a

# Function for finding L2 norm between diffrence of two vectors
# which takes arguments G: directed graph, d1 and d2: dictionaries
# returns L2 norm of difference between d1.values() and d2.values()
def find_L2norm(G,d1,d2):
	nodes = np.array(G.nodes())
	l2_norm = 0
	for i in nodes:
		l2_norm += (d1[i]-d2[i])**2 # summing the squared differences
	return math.sqrt(l2_norm)

# Loading the graph from so.txt to G
G = nx.DiGraph()
filename = "so.txt"
with open(filename) as f:
	line = f.readline()
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G.add_edge(a,b)
		line = f.readline()


# problem_2b part 1
h,a = HITS(G,100,1e-8)
# h and a have hub and authority scores respectively for each node
# Sort h and a in reverse order(to obtain max value first)
print("part 1")
sorted_h = sorted(h.items(),key=lambda item:item[1],reverse=True)
sorted_a = sorted(a.items(),key=lambda item:item[1],reverse=True)
# Display the top 5 hubs and authorities from sorted h and a dictionaries
print("------The top 5 Hubs-------")
print(str(sorted_h[0][0]) + ", " + str(sorted_h[1][0]) + ", " + str(sorted_h[2][0]) + ", " + str(sorted_h[3][0]) + ", " + str(sorted_h[4][0]))
print("------The top 5 Authorities-------")
print(str(sorted_a[0][0]) + ", " + str(sorted_a[1][0]) + ", " + str(sorted_a[2][0]) + ", " + str(sorted_a[3][0]) + ", " + str(sorted_a[4][0]))


# problem_2b part 2
print("part 2")
# Obtain h and a from library implementation
hl,al = nx.hits(G,500)
# Obtain h and a from self made function
h,a = HITS(G,500,1e-8)

# Display L2 norm for hub and authority scores
print("L2 norm for Hub scores: " + str(find_L2norm(G,h,hl)))
print("L2 norm for Authority scores: " + str(find_L2norm(G,a,al)))