# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import collections
import math
import numpy as np
import random

# function which returns the log(count) and log(degree) lists required for making the graph
# takes input G(graph)
def get_degrees_and_counts(G):
	# Obtain the degrees which appear in the graph and counts of nodes with those degrees
	degree_sequence = sorted([d for n, d in G.degree()], reverse=True)
	degrees = sorted(list(set(degree_sequence)))
	counts = []
	for i in degrees:
		counts.append(degree_sequence.count(i))

	# Store log values of counts and degrees in degrees_log and counts_log 
	degrees_log = []
	counts_log = []
	for i in degrees:
		if i==0:
			degrees_log.append(0)
		else:
			degrees_log.append(math.log10(i))
	for i in counts:
		if i==0:
			counts_log.append(0)
		else:
			counts_log.append(math.log10(i))

	return degrees_log,counts_log

# Function which plots the degree distribution on the basis of log(count) and log(degree) for all three graphs
# Scatter plot is drawn
def plot_degree_distribution(G1,G2,G3):
	degrees_log1, counts_log1 = get_degrees_and_counts(G1)
	degrees_log2, counts_log2 = get_degrees_and_counts(G2)
	degrees_log3, counts_log3 = get_degrees_and_counts(G3)
	fig, ax = plt.subplots()
	plt.scatter(degrees_log1,counts_log1, color='b', label='problem_3a')
	plt.scatter(degrees_log2,counts_log2, color='r', label="problem_3b")
	plt.scatter(degrees_log3,counts_log3, color='g', label="problem_3c")

	plt.legend(loc='upper right')
	plt.title("Degree distribution for problems_3a,3b,3c")
	plt.ylabel("log(Nk) where Nk=no.of nodes with degree k")
	plt.xlabel("log(k) where k=degree")
	plt.show()


# making graph problem_3a

# Function which takes n(no. of nodes) and l(no. of edges) as parameters
# returns graph G which has randomly placed L links among n nodes
def make_erdos_renyi_graph(n,l):
	G = nx.Graph()
	for i in range(1,n+1):
		G.add_node(i)
	non_edges = list(nx.non_edges(G))
	random.shuffle(non_edges) # randomly arrange the ordering of non-edges
	random.shuffle(non_edges)
	for i in range(l):
		nonedge = non_edges[i] # add non-edge one by one to graph
		G.add_edge(nonedge[0],nonedge[1])
	return G

N=5242
L=14484
G1 = make_erdos_renyi_graph(N,L)


# making graph problem_3b

n=5242
G2 = nx.Graph()
for i in range(1,n+1):
	G2.add_node(i)

#part 1 (make a simple cycle from n nodes)
for i in range(1,n):
	if i==1:
		G2.add_edge(1,n)
	G2.add_edge(i,i+1)

#part 2 (make edges among two hop neighbors)
for i in range(1,n-1):
	if i==1:
		G2.add_edge(1,n-1)
	if i==2:
		G2.add_edge(2,n)
	G2.add_edge(i,i+2)

#part 3 (place 4000 edges randomly)
for _ in range(4000):
	u = random.randint(1,n)
	v = random.choice([j for j in range(1,n+1) if j not in [u-2,u-1,u,u+1,u+2]]) # exclude the case when the edge is already made
	G2.add_edge(u,v)


# making graph problem_3c
G3 = nx.Graph()
filename = "arxiv.txt"
# Load the graph from arxiv file
with open(filename) as f:
	for _ in range(5):
		line = f.readline()
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G3.add_edge(a,b)
		line = f.readline()
G3.remove_edges_from(nx.selfloop_edges(G3))

plot_degree_distribution(G1,G2,G3)