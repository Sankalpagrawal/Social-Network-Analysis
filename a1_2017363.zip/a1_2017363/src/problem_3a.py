# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import random

# Function which takes n(no. of nodes) and l(no. of edges) as parameters
# returns graph G which has randomly placed L links among n nodes
def make_erdos_renyi_graph(n,l):
	G = nx.Graph()
	for i in range(1,n+1):
		G.add_node(i)
	non_edges = list(nx.non_edges(G))
	random.shuffle(non_edges) # randomly arrange the ordering of non-edges
	random.shuffle(non_edges)
	for i in range(l):
		nonedge = non_edges[i] # add non-edge one by one to graph
		G.add_edge(nonedge[0],nonedge[1])
	return G

N=5242
L=14484
graph = make_erdos_renyi_graph(N,L)