# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt

# Load the graph from arxiv file
G = nx.Graph()
filename = "arxiv.txt"
with open(filename) as f:
	for _ in range(5):
		line = f.readline()
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G.add_edge(a,b)
		line = f.readline()

print("Before eliminating repeats and self-edges:")
print("Number of nodes: " + str(G.number_of_nodes()))
print("Number of edges: " + str(G.number_of_edges()))

# Only self-loops are removed, as repeat edges are already removed while initializing the graph G as digraph in networkx
G.remove_edges_from(nx.selfloop_edges(G))

print("After eliminating repeats and self-edges:")
print("Number of nodes: " + str(G.number_of_nodes()))
print("Number of edges: " + str(G.number_of_edges()))