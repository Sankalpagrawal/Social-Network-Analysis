# Sankalp Agrawal, 2017363

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math

# First read G as a multidigraph(so that parallel edges could be included)
G = nx.MultiDiGraph()
filename = "so.txt"
with open(filename) as f:
	line = f.readline()
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G.add_edge(a,b)
		line = f.readline()

# problem_2a part 1
print("1. Number of weakly connected components: "+str(nx.number_weakly_connected_components(G)))
print("Number of strongly connected components: "+str(nx.number_strongly_connected_components(G)))

# problem_2a part 2
# Obtain the subgraph spanned by the set of nodes forming the largest weakly connected component,
# then count the number of edges
largest = max(nx.weakly_connected_components(G), key=len)
print("2. Number of nodes in the largest weakly connected component: " + str(len(largest)))
Gsub = G.subgraph(largest)
edges = Gsub.number_of_edges()
print("Number of edges in the largest weakly connected component: " + str(edges))


# Now read G as a digraph,so that pagerank and HITS algorithms can be performed
G = nx.DiGraph()
filename = "so.txt"
with open(filename) as f:
	line = f.readline()
	while line:
		a,b = list(map(int,line.strip().split("\t")))
		G.add_edge(a,b)
		line = f.readline()


# problem_2a part 3
d = nx.pagerank(G) # Obtain pagerank scores dictionary

# Obtain maximum pagerank score and store it in maxim
# Node with maximum pagerank score will be stored in maxim_node
maxim=-1
maxim_node=0
nodes=[]
pagerank_scores=[] # Score for each node will be stored here
for i in d:
	nodes.append(i)
	pagerank_scores.append(d[i])
	if d[i]>maxim:
		maxim=d[i]
		maxim_node=i

# Obtain the score values which appear in the graph and counts of nodes with those pagerank scores
scores = sorted(list(set(pagerank_scores)))
counts = []
for i in scores:
	counts.append(pagerank_scores.count(i))

# Store log values of counts and scores in degrees_log and scores_log 
scores_log = []
counts_log = []
for i in scores:
	if i==0:
		scores_log.append(0)
	else:
		scores_log.append(math.log10(i))
for i in counts:
	if i==0:
		counts_log.append(0)
	else:
		counts_log.append(math.log10(i))

print("3. Node with highest pagerank score: " + str(maxim_node))
print("Pagerank score: " + str(maxim))
# Plot the bar chart for pagerank values
plt.bar(scores_log,counts_log, width=0.10, color='b', edgecolor='k')
plt.title("Pagerank score distribution of nodes in the network")
plt.ylabel("log(NPR) where NPR=Number of nodes with pagerank value=PR")
plt.xlabel("log(PR) where PR=pagerank value")
plt.show()


# problem_2a part 4
h,a = nx.hits(G)
# h and a have hub and authority scores respectively for each node
# Sort h and a in reverse order(to obtain max value first)
sorted_h = sorted(h.items(),key=lambda item:item[1],reverse=True)
sorted_a = sorted(a.items(),key=lambda item:item[1],reverse=True)
# Display the top 5 hubs and authorities from sorted h and a dictionaries
print("4. The top 5 Hubs are: ")
print(str(sorted_h[0][0]) + ", " + str(sorted_h[1][0]) + ", " + str(sorted_h[2][0]) + ", " + str(sorted_h[3][0]) + ", " + str(sorted_h[4][0]))
print("The top 5 Authorities are: ")
print(str(sorted_a[0][0]) + ", " + str(sorted_a[1][0]) + ", " + str(sorted_a[2][0]) + ", " + str(sorted_a[3][0]) + ", " + str(sorted_a[4][0]))